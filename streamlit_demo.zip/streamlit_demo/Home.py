import streamlit as st

st.title("Home")
st.write("Provide a short description of the problem and your objective.")
st.write("Provide a list of your names and github handles")
