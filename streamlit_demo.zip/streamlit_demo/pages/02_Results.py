import streamlit as st

st.title("Results")
st.write("Here you can put each of your key results.")
