import streamlit as st

st.title("Summary")
st.write("Here you can provide a short summary and recommendations")
