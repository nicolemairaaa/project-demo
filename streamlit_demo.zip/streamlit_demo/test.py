import streamlit as st
st.write("Hello, let's learn how to build a streamlit app together")